package QueuePackage;
/**
 * A class that implements the ADT deque by using a doubly linked chain of
 * nodes.
 * 
 * @author Frank M. Carrano
 * @author Timothy M. Henry
 * @version 5.0
 */
public class LinkedDeque<T> implements DequeInterface<T> {
	private DoublyLinkedNode<T> firstNode; // References node at front of deque
	private DoublyLinkedNode<T> lastNode; // References node at back of deque
	int numberOfEntries;
	
	public LinkedDeque() {
		firstNode = null;
		lastNode = null;
		numberOfEntries = 0;
	}

	@Override
	public void addToFront(T newEntry) {
		
		DoublyLinkedNode<T> newNode = new DoublyLinkedNode<>(null, newEntry, firstNode);
		if(isEmpty())
			lastNode = newNode;
		else
			firstNode.setPreviousNode(newNode);
		
		firstNode = newNode;
		numberOfEntries++;
	}

	@Override
	public void addToBack(T newEntry) {
		//set the previous node for the entry, and next is null
		DoublyLinkedNode<T> newNode = new DoublyLinkedNode<>(lastNode, newEntry, null);
		
		if(isEmpty())
			firstNode = newNode;
		else
			lastNode.setNextNode(newNode);
		
		lastNode = newNode;
		numberOfEntries++;
	}

	@Override
	public T removeFront() {
		T front = getFront();
		
		if(front == null)
			return null;
		
		firstNode = firstNode.getNextNode();
		if(firstNode == null)
			lastNode = null;
		else
			firstNode.setPreviousNode(null);
		numberOfEntries--;
		return front;
	}

	@Override
	public T removeBack() {
		T back = getBack();
		if(back == null)
			return null;
		
		lastNode = lastNode.getPreviousNode();
		if(lastNode == null)
			firstNode = null;
		else
			lastNode.setNextNode(null);
		numberOfEntries--;
		return back;
	}

	@Override
	public T getFront() {
		if (isEmpty())
			throw new EmptyQueueException();
		else
			return firstNode.getData();
	}

	@Override
	public T getBack() {
		if (isEmpty())
			throw new EmptyQueueException();
		else
			return lastNode.getData();
	}

	@Override
	public boolean isEmpty() {
		return (firstNode == null) && (lastNode == null);
	}

	@Override
	public void clear() {
		firstNode = null;
		lastNode = null;
		numberOfEntries = 0;
	}

	@Override
	public int size() {
		return numberOfEntries;
	}

	@Override
	public T[] toArray() {
		T[] items = (T[]) new Object[size()]; // create new array
		int index = 0;
		for(Node<T> currentNode = firstNode; currentNode != null; currentNode = currentNode.getNextNode()) {
			items[index] = currentNode.getData();
			index++;
		}
		return items;
	} 


} 
