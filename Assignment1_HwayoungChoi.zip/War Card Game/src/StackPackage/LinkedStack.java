package StackPackage;

import java.util.EmptyStackException;

/**
 * A class of stacks whose entries are stored in a chain of nodes.
 * 
 * @author Frank M. Carrano
 * @author Timothy M. Henry
 * @version 5.0
 * 
 * @author mhrybyk
 * -> completed (HwayoungChoi)
 * modified to use public Node class
 * 
 * added toArray() and size() implementations to reflect modified
 * StackInterface
 */
public class LinkedStack<T> implements StackInterface<T> {
	private Node<T> topNode; // References the first node in the chain
	private int numberOfEntries;

	public LinkedStack() {
		topNode = null;
		numberOfEntries = 0;
	}

	@Override
	public void push(T newEntry) {
		Node<T> newNode = new Node<T>(newEntry, topNode); //create new node
		
		topNode = newNode; //set the top to the new node
		numberOfEntries++;
	}

	@Override
	public T pop() {
		T top = peek(); //get the top node
		
		topNode = topNode.getNextNode(); //set the top to the next node
		numberOfEntries--;
		return top;
	}

	@Override
	public T peek() {
		if (isEmpty())
			throw new EmptyStackException();
		else return topNode.getData();
	}

	@Override
	public boolean isEmpty() {
		return topNode == null;
	}

	@Override
	public void clear() {
		topNode = null;
		numberOfEntries = 0;
	}

	@Override
	public int size() {
		return numberOfEntries;
	}

	@Override
	public T[] toArray() {
		T[] tempStack = (T[]) new Object[size()]; //create new array
		
		int index = size() - 1;
		for (Node<T> currentNode = topNode; currentNode != null; currentNode = currentNode.getNextNode()) {
			//top of the stack needs to be the last item in the array
			tempStack[index] = currentNode.getData(); 
			index--;
		}
		return tempStack;
	}
}
