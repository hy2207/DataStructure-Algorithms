package WarCardGamePackage;

import QueuePackage.*;

/**
 * Class representing a deck of cards using an internal queue. 
 * 
 * Uses methods from the Deck base class.
 * -->Checked (HwayoungChoi)
 */

public class DeckUsingQueue extends Deck {

	private QueueInterface<Card> queue;

	public DeckUsingQueue(String name) {
		super(name);
//		queue = new CompletedArrayQueue<Card>();
//		queue = new CompletedLinkedQueue<>();
//		queue = new CompletedTwoPartCircularLinkedQueue<>();
//		queue = new ArrayQueue<Card>();
//		queue = new LinkedQueue<>();
		queue = new TwoPartCircularLinkedQueue<>();
	}	

	@Override
	public void addCard(Card card) {
		queue.enqueue(card);
		
	}

	@Override
	public Card removeCard() {
		return queue.dequeue();
	}

	@Override
	public boolean isEmpty() {
		return queue.isEmpty();
	}

	@Override
	public int size() {
		return queue.size();
	}

	@Override
	public Object[] toArray() {		
		return queue.toArray();
	}

	@Override
	public void clear() {
		queue.clear();
		
	}
	

}
