package WarCardGamePackage;

/**
 * A player in the game of war.
 * The player is initialized with a name, which is used to identify the player in output 
 * @author mhrybyk
 * --> Completed (HwayoungChoi)
 */
public class Player implements PlayerInterface {

	private String name;  // name of the player
	
	// each player has three decks
	// cardsToPlay - the cards to be used to play war, chosen one at a time
	// cardsWon - storage for all cards won in each battle
	// war - only used when there is a war
	
	private DeckInterface cardsToPlay;
	private DeckInterface cardsWon;
	private DeckInterface war;

	public Player(String name) {
		this.name = name;
		
		// comment out the decks to be used - those using a stack or a queue
		// both should be tested thoroughly
//		
		cardsToPlay = new DeckUsingStack("[CardsToPlay - Stack]");
		cardsWon = new DeckUsingStack("[CardsWon - Stack]");
		war = new DeckUsingStack("[War - Stack]");
//		
//		cardsToPlay = new DeckUsingQueue("[CardsToPlay - Queue]");
//		cardsWon = new DeckUsingQueue("[CardsWon - Queue]");
//		war = new DeckUsingQueue("[War - Queue]");
	}
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public void addCardToPlay(Card card) {
		cardsToPlay.addCard(card);
	}

	@Override
	public Card getCardToPlay() {
		Card playerCard = null;
		if(!cardsToPlay.isEmpty()) {
			playerCard = cardsToPlay.removeCard(); //remove playedCard from deck 
		} else if(!cardsWon.isEmpty()) {
			cardsWon.shuffle(); // no more cards -> reshuffle
			while(!cardsWon.isEmpty()) { 
				cardsToPlay.addCard(cardsWon.removeCard());	//copy cards to play deck & clear wondeck			
			}
			playerCard = cardsToPlay.removeCard();
		} else {
			playerCard = null;
		}
		return playerCard; 
	}

	@Override
	public void addWonCard(Card card) {
		cardsWon.addCard(card);	
	}

	@Override
	public boolean declareWar(Card playedCard) {

		war.addCard(playedCard); //put the played card
		//player needs more than 4 cards to keep playing
		if(cardsToPlay.size() + cardsWon.size() < 4) {
			return false;
		} else {
			for(int i = 0; i < 3; i++) {
				war.addCard(getCardToPlay()); //put 3 more cards in war deck				
			}
			return true;
		}
	}

	@Override
	public void lostWarTo(PlayerInterface otherPlayer) {
		while(!war.isEmpty()) {
			otherPlayer.addWonCard(war.removeCard());
		}
	}

	@Override
	public void wonWar() {
		while(!war.isEmpty()) {
			addWonCard(war.removeCard());
		}
	}

	@Override
	public DeckInterface getCardsToPlayDeck() {
		return cardsToPlay;
	}

	@Override
	public DeckInterface getCardsWonDeck() {
		return cardsWon;
	}

	@Override
	public DeckInterface getWarDeck() {
		return war;
	}
	
	@Override
	public String toString() {
		return name + " <ToPlay(" + cardsToPlay.size() + 
				") Won(" + cardsWon.size() +
				") War(" + war.size() + ")>";
	}

}
