package WarCardGamePackage;

import StackPackage.*;

/**
 * Class representing a deck of cards using an internal stack. 
 * 
 * Uses methods from the Deck base class.
 * 
 * @author mhrybyk
 * --> allchecke (HwayoungChoi)
 */

public class DeckUsingStack extends Deck {

	private StackInterface<Card> stack;

	public DeckUsingStack(String name) {
		super(name);
		
		// comment out the stack implementation to use
		
//		stack = new CompletedArrayStack<Card>();
//		stack = new CompletedLinkedStack<Card>();
//		stack = new CompletedVectorStack<Card>();
		
		stack = new ArrayStack<Card>();
//		stack = new LinkedStack<Card>();
//		stack = new VectorStack<Card>();
	}	

	@Override
	public void addCard(Card card) {
		stack.push(card);
	}

	@Override
	public Card removeCard() {
		return stack.pop();
	}

	@Override
	public boolean isEmpty() {
		return stack.isEmpty();
	}

	@Override
	public int size() {
		return stack.size();
	}

	@Override
	public Object[] toArray() {		
		return stack.toArray();
	}

	@Override
	public void clear() {
		stack.clear();
	}
	

}
