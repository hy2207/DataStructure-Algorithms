package WarCardGamePackage;
import java.util.Random;

/**
 * A common abstract base class that provides common methods for a deck of cards.
 * @author mhrybyk
 * -->Checked (HwayoungChoi)
 */

public abstract class Deck implements DeckInterface {

	private String name;

	public Deck(String name) {
		this.name = name;
	}	
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Shuffle the deck
	 * First copy the card deck to an array. Then shuffle the array.
	 * Clear the deck, then add the cards from the shuffled array back to the deck.
	 */
	public void shuffle() {
		Object[] cards = toArray();
		int deckSize = size();
		
		// initialize the random number generator
		Random random = new Random();
		random.nextInt();

		// shuffle by picking a random card from the remaining
		// cards and trading places with the selected card
		
		int newLocation; // place in the array to swap
		Object temp;  // temp storage for the swap
		
		for (int i = 0; i < deckSize; i++) {
			
			// the new location is the current card plus a random selection 
			// from all remaining cards
			newLocation = i + random.nextInt(deckSize - i);
			// now swap the current card to the new location
			temp = cards[i];
			cards[i] = cards[newLocation];
			cards[newLocation] = temp;
		}	
		
		// clear the deck
		
		clear();
		
		// copy the shuffled card array to the deck
		
		for(Object card : cards)
			addCard((Card) card);
		
	}

}
