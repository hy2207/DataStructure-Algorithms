package WarCardGamePackage;
/**
 * main program and logic
 * create 2 players' deck
 * display game process
 * determines when game is over 
 * 
 * @author HwayoungChoi
 * 
 */
public class WarCardGame {

	public static void main(String[] args) {

		// create and display the deck of cards
		// use either a stack or a queue, both should be tested
		DeckInterface deck = new DeckUsingStack("Card Deck Using Stack");
//		DeckInterface deck = new DeckUsingQueue("Card Deck Using Queue");
		
		createStandardCardDeck(deck);

		displayDeck(deck, "Unshuffled");
		deck.shuffle();
		displayDeck(deck, "Shuffled");
		
		// create the two players
		
		PlayerInterface player1 = new Player("Brother");
		PlayerInterface player2 = new Player("Sister");

		// deal cards to each player and display their hands
		
		int playerCardNum = deck.size()/2; //divided by number of players
		
		for (int i = 0; i < playerCardNum; i++)
			player1.addCardToPlay(deck.removeCard());
		
		for (int i = 0; i < playerCardNum; i++)
			player2.addCardToPlay(deck.removeCard());
		
		//display cards initially each player
		displayDeck(player1.getCardsToPlayDeck(), player1.toString());
		displayDeck(player2.getCardsToPlayDeck(), player2.toString());

		// GAME LOGIC CODE HERE
		int roundNum = 1; //set the round number
		boolean endGame = false; //if it is true the one of the player doesn't have any card to play
		Card card1, card2; // each player card
		boolean declareWar = false; //declare war
		
		while(!endGame) {
			
			System.out.println("Round "+roundNum); 
			System.out.println(player1.toString()); //player1's info
			System.out.println(player2.toString()); //player2's info
			card1 = player1.getCardToPlay(); 
			card2 = player2.getCardToPlay();
			
			if(card1 == null) { //if there is no card that player loses
				System.out.println(player1.toString() + " loses");
				endGame = true;
				break;
			} else if (card2 == null) {
				System.out.println(player2.toString() + " loses");
				endGame = true;
				break;
			}
			
			System.out.println(player1.toString() + " [" + card1 + "]" + " vs " 
					+ player2.toString() + " [" + card2 + "]");
			
			int compareCard = card1.compareTo(card2); //card1>card2: returns positive value, card1=card2: 0, card1<card2: negative value
			
			if(compareCard > 0) { 
				declareWar = displayWinner(player1, card1, player2, card2, declareWar); //player1 wins
			} else if(compareCard <0) {
				declareWar = displayWinner(player2, card2, player1, card1, declareWar);
			} else {
				System.out.println("xxxxx War declared xxxxx");
				declareWar = player1.declareWar(card1); //change declarewar status and add card to war deck
				player2.declareWar(card2);
				displayDeck(player1.getWarDeck(), player1.toString());
				displayDeck(player2.getWarDeck(), player2.toString());	
			}
				
			System.out.println("*******************");
			roundNum++; //next round
		}		
	}
	
	/**
	 * Using the Suit and CardType enums, create a full deck of cards.
	 * For each suit and card type, add the card to the deck
	 */
	public static void createStandardCardDeck(DeckInterface deck) {
		for(Suit suit : Suit.values()) { 
			for(CardType cardType : CardType.values()) {
				if(cardType.getCardTypeValue() == 0) { //number Case
					for(int cardNum =2; cardNum <= 10; cardNum++ )
					deck.addCard(new Card(suit, cardType, cardNum));
				} else { 
					deck.addCard(new Card(suit, cardType, cardType.getCardTypeValue() + 10));
				}
			}
		}
	}
	
	
	/**
	 * Display all elements in the deck using the title
	 * @param title title to be displayed before the list of elements are shown
	 */
	static public void displayDeck(DeckInterface deck, String title) {
		
		int deckSize = deck.size();
		
		System.out.println("===================");
		System.out.println(title + deck.getName() + " size " + deckSize);
		for (int i = 0; i < deckSize; i++) {
			System.out.println(deck.toArray()[i]);
		}
		System.out.println("===================");

	}
	/**
	 * 
	 * @param winner who is winner in the round
	 * @param loser who is loser in the round
	 * @param war has true boolean value if there war is declared
	 */
	static public boolean displayWinner(PlayerInterface winner, Card winnerCard, PlayerInterface loser, Card loserCard, boolean war) {

		winner.addWonCard(winnerCard);
		winner.addWonCard(loserCard);
		//if war is declared before comparing
		if(war) {
			winner.wonWar();
			loser.lostWarTo(winner);
			war = false; //next no war
		}
		System.out.println(winner.toString() + " wins round");
		return war;
	}	
	
}
