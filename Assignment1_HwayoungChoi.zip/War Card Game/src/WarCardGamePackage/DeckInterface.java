package WarCardGamePackage;

/**
 * Specification for methods that operate on a deck of cards.
 * 
 * @author mhrybyk
 *-->checked (HwayoungChoi)
 */
public interface DeckInterface {
	
	/**
	 * @return the name
	 */
	public String getName();

	/**
	 * @param name the name to set
	 */
	public void setName(String name);
	
	/**
	 * Shuffle the deck by removing each element from the queue and adding them
	 * to an array.
	 * Then shuffle the array.
	 * Finally add each array element back onto the queue.
	 */
	public void shuffle();
	
	/**
	 * Add a card to the deck
	 * @param card card to be added
	 */	
	public void addCard(Card card);
	
	/**
	 * Remove a card from the deck
	 * @return the removed card
	 */
	public Card removeCard();
	
	/**
	 * Checks to see if the deck is empty
	 * @return true if there are no cards in the deck
	 */
	public boolean isEmpty();
	
	/**
	 * Clears the deck
	 */
	public void clear();
	
	/**
	 * Gets the number of cards in the deck
	 * @return the size of the deck
	 */
	public int size();
	
	/**
	 * Gets a copy of all cards in the deck
	 * @return an array of cards consisting of copies of all card in the deck
	 */
	public Object[] toArray();

}
