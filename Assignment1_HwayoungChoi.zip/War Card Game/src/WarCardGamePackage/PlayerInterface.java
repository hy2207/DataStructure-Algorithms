package WarCardGamePackage;

public interface PlayerInterface {
	/**
	 * Get the player's name
	 * @return player's name
	 */
	public String getName();

	/**
	 * Set the player's name
	 * @param name player's name
	 */
	public void setName(String name);
	
	/**
	 * Add a card to the cards to play deck. This is used when the main deck is being
	 * dealt.
	 * @param card
	 */
	void addCardToPlay(Card card);

	/**
	 * Return the next card to play and remove it from the deck.
	 * If there are no more cards in the deck, 
	 *   reshuffle the cards won deck
	 *   copy the cards from the won deck to the cards to play deck
	 *   clear the won deck
	 *   restart, getting a card from the card to play deck now that it is
	 *   guaranteed to have cards.
	 *   If there are no more cards in either deck, the player loses.
	 * @return
	 */
	Card getCardToPlay();

	/**
	 * Add a card to the won deck
	 * @param card
	 */
	void addWonCard(Card card);

	/**
	 * Put the playedCard and the next three cards into the war deck
	 * @param playedCard
	 * @return
	 */
	boolean declareWar(Card playedCard);

	/**
	 * Lost the war, so move all of the war deck to the other player's won deck.
	 * @param otherPlayer
	 */
	void lostWarTo(PlayerInterface otherPlayer);

	/**
	 * Won the war, so move all of our war deck to won deck.
	 */
	void wonWar();

	/**
	 * Get the deck of cards that are to be played
	 * @return cardsToPlay deck
	 */
	public DeckInterface getCardsToPlayDeck(); 

	/**
	 * Get the deck of cards that have been won so far
	 * @return cardsWon deck
	 */
	public DeckInterface getCardsWonDeck();

	/**
	 * Get the deck formed from a war
	 * @return war deck
	 */
	public DeckInterface getWarDeck();

}