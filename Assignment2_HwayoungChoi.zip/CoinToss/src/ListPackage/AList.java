package ListPackage;

import java.util.Arrays;

/**
 * A class that implements the ADT list by using a fixed array. Duplicate
 * entries are allowed.
 * 
 * 
 * @author Frank M. Carrano
 * @author Timothy M. Henry
 * 
 * @version 5.0
 * 
 * @author mhrybyk --> Redone to simplify and make everything zero index based
 *         Array is no longer resized, just returns false if item cannot be
 *         added.
 * 
 *--> Completed (HwayoungChoi)
 */
public class AList<T extends Comparable<? super T>> implements ListInterface<T> {
	private T[] list; // Array of list entries
	private int numberOfEntries;

	private static final int DEFAULT_CAPACITY = 25;
	private static final int MAX_CAPACITY = 10000;

	public AList() {
		this(DEFAULT_CAPACITY);
	} // end default constructor

	public AList(int initialCapacity) {

		// Is initialCapacity too small?
		if (initialCapacity < DEFAULT_CAPACITY)
			initialCapacity = DEFAULT_CAPACITY;

		// cap it at maximum capacity

		if (initialCapacity >= MAX_CAPACITY)
			initialCapacity = MAX_CAPACITY;

		// The cast is safe because the new array contains null entries
		@SuppressWarnings("unchecked")
		T[] tempList = (T[]) new Comparable[initialCapacity];
		list = tempList;

		numberOfEntries = 0;

	}

	@Override
	public boolean add(T newEntry) {
		try {
			ensureCapacity(); // check capacity
		} catch (Exception e) {
			return false;
		}

		list[numberOfEntries] = newEntry; // add newEntry
		numberOfEntries++;
		return true; // true if the addition was successful
	}

	@Override
	public boolean add(int newPosition, T newEntry) {
		if (hasRoom() == false) // check having room
			return false;
		// if list is empty, ignore the position and add
		if (isEmpty()) {
			list[0] = newEntry;
			numberOfEntries = 1;
			return true;
		}
		// needs to be in range
		if (newPosition < 0 || newPosition > numberOfEntries)
			return false;

		// shift all entries starting at the desired position
		// for the new entry up by one to make room
		for (int index = numberOfEntries - 1; index >= newPosition; index--) {
			list[index + 1] = list[index];
		}
		list[newPosition] = newEntry; // set new entry into the vacated position

		numberOfEntries++; // increment size

		return true;
	}

	@Override
	public T remove(int givenPosition) {
		if (!isInRange(givenPosition)) // check given position is in range
			throw new IndexOutOfBoundsException();

		T result = list[givenPosition]; // get entry

		// shift all of the elements of the array down to cover the removed slot
		for (int index = givenPosition; index < numberOfEntries; index++) {
			list[index] = list[index + 1];
		}

		numberOfEntries--; // decrement size
		return result;
	}

	@Override
	public boolean removeEntry(T anEntry) {
		int position = findEntry(anEntry); // find andEntry, then remove it if it exists

		if (position < 0)
			return false;
		else {
			if (remove(position) != null)
				return true;
			else
				return false;
		}
	}

	@Override
	public void clear() {

		// clear entries but retain array
		for (int index = 0; index < numberOfEntries; index++)
			list[index] = null;

		numberOfEntries = 0;
	}

	@Override
	public T replace(int givenPosition, T newEntry) {

		if (!isInRange(givenPosition))
			throw new IndexOutOfBoundsException();

		// replace entry to new entry in given position
		T replaced = list[givenPosition];
		list[givenPosition] = newEntry;

		return replaced;

	}

	@Override
	public T getEntry(int givenPosition) {

		// if a legal position, return the data in the array slot
		if (!isInRange(givenPosition))
			throw new IndexOutOfBoundsException();

		return list[givenPosition];
	}

	@Override
	public int findEntry(T anEntry) {
		int position = 0;

		// if the entry exists, loop sill end when found
		while ((position < numberOfEntries) && !anEntry.equals(getEntry(position))) {
			position++;
		}
		// return -1 if not found as the entire lists has been traversed
		return position == numberOfEntries ? -1 : position;
	}

	@Override
	public T[] toArray() {
		return (T[]) Arrays.copyOf(list, numberOfEntries);
	}

	@Override
	public boolean contains(T anEntry) {
		return findEntry(anEntry) >= 0; // true if anEntry is in the list
	}

	@Override
	public int size() {
		return numberOfEntries;
	}

	@Override
	public boolean isEmpty() {
		return numberOfEntries == 0; // true if a list is empty
	}

	/**
	 * Determines if a position is in the proper range of the list
	 * 
	 * @param givenPosition
	 * @return
	 */
	public boolean isInRange(int givenPosition) {
		return (givenPosition >= 0) && (givenPosition < numberOfEntries);
	}

	/**
	 * Determine if there is no more room in the list to add entries
	 * 
	 * @return true if the list is full
	 */
	public boolean isFull() {
		if (numberOfEntries >= list.length)
			return true;
		else
			return false;
	}

	/**
	 * Determines if there is room in the list to add entries
	 * 
	 * @return true if there is room in the list
	 */
	public boolean hasRoom() {
		if (numberOfEntries < list.length)
			return true;
		else
			return false;
	}

	/**
	 * Doubles the capacity of the array if it is full
	 */
	private void ensureCapacity() {
		if (isFull()) {
			int newCapacity = 2 * size();
			checkCapacity(newCapacity); // Is capacity too big
			list = Arrays.copyOf(list, newCapacity);
		}
	}

	/**
	 * Throws an exception if the client requests a capacity that is either too
	 * small or too large
	 * 
	 * @param capacity
	 */
	private void checkCapacity(int capacity) {
		if (capacity < DEFAULT_CAPACITY) // too small
			throw new IllegalStateException(
					"Attempt to a create an array whose capacity is smaller than " + DEFAULT_CAPACITY);
		else if (capacity > MAX_CAPACITY) // too large
			throw new IllegalStateException("Attempt to create an array whose capacity is larger than " + MAX_CAPACITY);
	}

}
