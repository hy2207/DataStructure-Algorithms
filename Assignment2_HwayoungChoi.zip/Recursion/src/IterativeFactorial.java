/**
 * Simple iterative factorial
 * @author HwayoungChoi
 *
 */
public class IterativeFactorial implements SequenceInterface {
	
	private String name;
	private int numberOfCalls = 0;
	
	// set the name of the sequence 
	public IterativeFactorial(String name) {
		this.name = name;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
		
	}
	
	/**
	 * Compute the factorial using iteration
	 * @param n
	 * @return factorial
	 */

	public long compute(long n) {
		numberOfCalls++; // increase when compute function is called
		long result = 1; // initialized to 1 (identity element) also if n is 0, the result is 1 (basecase)
		while (n > 1) {
			result *= n;
			n--;
		}
		return result;
	}

	@Override
	public void resetNumberOfCalls() {
		numberOfCalls = 0;
		
	}

	@Override
	public int getNumberOfCalls() {
		return numberOfCalls;
	}

}
