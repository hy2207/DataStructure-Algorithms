/**
 * Compute factorial using tail recursion
 * @author HwayoungChoi
 * 
 */
public class TailRecursiveFactorial implements SequenceInterface {
	private String name;
	private int numberOfCalls = 0; 	// counter to keep number of recursive calls
	
	// set the name of the sequence 
	public TailRecursiveFactorial(String name) {
		this.name = name;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
		
	}
	
	@Override
	public void resetNumberOfCalls() {
		numberOfCalls = 0;
		
	}

	@Override
	public int getNumberOfCalls() {
		return numberOfCalls;
	}
	
	/**
	 * The tail recursive version of factorial.
	 * 
	 * @param n The number to compute factorial of.
	 * @return n factorial.
	 */
	public long compute(long n) { 
		return computeHelper(n, 1);
	}
	/**
	 * Helper method for computing factorial using tail recursion
	 * 
	 * @param n
	 * @param factorial (partial result)
	 * @return
	 */
	public long computeHelper(long n, long factorial) {
		numberOfCalls++; // increase when compute function is called
		long result = 1;

		if (n <= 1)
			result = factorial; // result of 0! and 1! = 1
		else {
			result = computeHelper(n - 1, factorial * n);
		}
		return result;
	}

}
