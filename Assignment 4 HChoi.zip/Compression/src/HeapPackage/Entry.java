package HeapPackage;

/**
 * A class that represents an entry for a priority queue.
 * 
 * @author Frank M. Carrano
 * @author Timothy M. Henry
 * @author Charles Hoot
 * @version 5.0
 */
public class Entry<E, P extends Comparable<? super P>>
             implements Comparable<Entry<E, P>>
{
   private E theItem;
   private P thePriority;

   public Entry(E item, P priority)
   {
      theItem = item;
      thePriority = priority;
   } 

   public E getItem()
   {
      return theItem;
   } 

   public P getPriority()
   {
      return thePriority;
   } 

   public int compareTo(Entry<E, P> other)
   {
      return thePriority.compareTo(other.thePriority);
   } 

   public String toString()
   {
      return "item/priority <" + theItem + ", " + thePriority + ">";
   } 
} 
