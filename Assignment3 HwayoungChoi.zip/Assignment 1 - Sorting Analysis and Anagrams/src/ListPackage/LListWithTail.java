package ListPackage;

/**
 * A linked implemention of the ADT list.
 * 
 * @author Frank M. Carrano
 * @author Timothy M. Henry
 * @version 5.0
 * 
 * @author mhrybyk
 *         modified to use a zero offset for position Uses Node class which is
 *         doubly-linked, but only use forward links here
 *         
 *--> Completed (HwayoungChoi)
 */
public class LListWithTail<T extends Comparable<? super T>> implements ListInterface<T> {
	private Node<T> firstNode; // Reference to first node of chain
	private Node<T> lastNode; // Reference to last node of chain
	private int numberOfEntries;

	public LListWithTail() {
		initializeDataFields();
	}

	/**
	 * Reset all data in the list.
	 */
	private void initializeDataFields() {
		firstNode = null;
		lastNode = null;
		numberOfEntries = 0;
	}

	/**
	 * Return the first node in the list. Violates data hiding.
	 * 
	 * Only used by iterator. In production, the subclass would be final,
	 * or the iterator would be built in from the start.
	 * @return
	 */
	protected Node<T> getFirstNode() {
		return firstNode;
	}

	@Override
	public boolean add(T newEntry) {
		Node <T> newNode = new Node<>(newEntry);
		
		if(isEmpty()) {
			firstNode = newNode;
		} else {
			lastNode.setNextNode(newNode); //set current last node reference new node
		}
		
		lastNode = newNode; //reset last node to be the new one added
		numberOfEntries++;
		
		return true;
	}

	@Override
	public boolean add(int newPosition, T newEntry) {
		if(isInRange(newPosition) || newPosition == numberOfEntries) {
			
			Node<T> newNode = new Node<>(newEntry);
			
			if(isEmpty()) {
				firstNode = newNode;
				lastNode = newNode;
			} else if (newPosition == 0) { 
				//at the start node
				newNode.setNextNode(firstNode); 
				firstNode = newNode;
			} else if (newPosition == numberOfEntries) {
				// at the end node
				lastNode.setNextNode(newNode);
				lastNode = newNode;				
			} else { 
				//in the middle of the list
				Node<T> nodeBefore = getNodeAt(newPosition - 1);
				Node<T> nodeAfter = nodeBefore.getNextNode();
				//insert the new node btw the existing nodes
				newNode.setNextNode(nodeAfter);
				nodeBefore.setNextNode(newNode);
			}
			numberOfEntries++;
			return true;
		} else
			return false;
	}

	@Override
	public T remove(int givenPosition) {
		if(!isInRange(givenPosition))
			throw new IndexOutOfBoundsException();
		
		T result = null;
		
		if(givenPosition==0) {
			//first entry case
			result = firstNode.getData(); //save the removed node's data
			firstNode = firstNode.getNextNode(); //remove the entry
		} else {
			Node<T> nodeBefore = getNodeAt(givenPosition - 1); //find before node at the given position
			Node<T> nodeToRemove = nodeBefore.getNextNode(); //get the next node (one to remove)
			
			result = nodeToRemove.getData(); //save the removed node's data
			
			Node<T> nodeAfter = nodeToRemove.getNextNode(); 
			nodeBefore.setNextNode(nodeAfter); //setting the pointer of the previous node to the remove node's next
			
			if (givenPosition == numberOfEntries - 1)
				lastNode = nodeBefore;
		}
		numberOfEntries--;
		return result;
	}

	@Override
	public boolean removeEntry(T anEntry) {
		int position = findEntry(anEntry); //find anEntry
		
		if(position < 0) //Entry doesn't exist
			return false;
		else {
			if (remove(position) != null)
				return true;
			else 
				return false;
		}
	}

	@Override
	public void clear() {
		//clear all entry
		initializeDataFields();
	}

	@Override
	public T replace(int givenPosition, T newEntry) {
		if(!isInRange(givenPosition))
			throw new IndexOutOfBoundsException();
		
		Node<T> desiredNode = getNodeAt(givenPosition); //find the node
		T originalEntry = desiredNode.getData(); 
		desiredNode.setData(newEntry); //replace its data
		return originalEntry;
	}

	@Override
	public T getEntry(int givenPosition) {
		if(!isInRange(givenPosition))
			throw new IndexOutOfBoundsException();
		
		return getNodeAt(givenPosition).getData();
	}

	@Override
	public int findEntry(T anEntry) {
		//same wit LList
		boolean found = false;
		int position = 0;
		Node<T> currentNode = firstNode;
		
		while(!found && (currentNode != null)) {
			if(anEntry.equals(currentNode.getData()))
				found = true;
			else {
				currentNode = currentNode.getNextNode();
				position++;
			}
		}
		if(found == true)
			return position;
		else {
			return -1;
		}
	}

	@Override
	public T[] toArray() {
		//same with toArray() in LList
		@SuppressWarnings("unchecked")
		T[] result = (T[]) new Comparable[numberOfEntries];
		
		int index = 0;
		Node<T> currentNode = firstNode;
		while ((index<numberOfEntries) && (currentNode != null)) {
			result[index] = currentNode.getData();
			currentNode = currentNode.getNextNode();
			index++;
		}
		return result;
	}

	@Override
	public boolean contains(T anEntry) {
		return findEntry(anEntry) >= 0; 
	}

	@Override
	public int size() {
		return numberOfEntries;
	}

	@Override
	public boolean isEmpty() {
		return numberOfEntries == 0;
	}

	/**
	 * Determines if a position is in the proper range of the list
	 * 
	 * @param givenPosition
	 * @return
	 */
	public boolean isInRange(int givenPosition) {
		return (givenPosition >= 0) && (givenPosition < numberOfEntries);
	}

	/**
	 * Returns a reference to the Node<T> at a given position.
	 * 
	 * @param givenPosition
	 * @return
	 */
	private Node<T> getNodeAt(int givenPosition) {
		if(isEmpty() || !isInRange(givenPosition))
			return null;
		//if the last position in the list is desired, no need to traverse it
		if(givenPosition == numberOfEntries - 1)
			return lastNode;
		
		Node<T> currentNode = firstNode; 
		//Traverse the chain to locate the desired node
		for(int counter = 0; counter < givenPosition; counter++)
			currentNode = currentNode.getNextNode();
		
		return currentNode;
	}

}
