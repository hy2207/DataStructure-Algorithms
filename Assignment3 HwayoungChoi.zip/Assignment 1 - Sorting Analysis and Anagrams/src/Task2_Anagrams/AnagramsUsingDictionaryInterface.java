package Task2_Anagrams;
import java.util.*;

import DictionaryPackage.*;
import HashingPackage.*;

import java.io.*;

/**
 * Anagrams using hash dictionary
 * 
 * @author HwayoungChoi
 *
 */
public class AnagramsUsingDictionaryInterface {
	public static void main(String[] args) throws IOException {
		
		// comment out one of these lines to test
		//when HashedDictionary is used, it takes more time than using hashmap library
//		DictionaryInterface<String, ArrayList<String>> anagrams = new HashedDictionary<String, ArrayList<String>>();
		DictionaryInterface<String, ArrayList<String>> anagrams = new HashMapDictionary<String, ArrayList<String>>();
		
		String[] testWords = {
				"thesis",
				"server",
				"sublet",
				"reverse",
				"retraced",
				"stripes",
				"evils",
				"nailset",
				"reliant",
				"demo",
				"deer",
				"rifles",
				"baritone",
				"pointer",
				"cobra",
				"strip",
				"sterling",
				"earliest",
				"rowth",
				"reshoot",
				"presplit",
				"teach",
				"scare",
				"bread",
				"outrage"
		};

		// get all anagrams for all words in the file.
		createAnagrams("src\\Task2_Anagrams\\dictionary.txt", anagrams);

		// display all anagrams for the list of test words to the console
		
		System.out.println("******** Showing anagrams for test words");
		
		// insert your code here to display on the console the anagrams for the test words above.
		// the output should match anagramsTestWordsOutput.txt exactly
		
		for(String key : testWords){
			System.out.println("Anagrams for " + key +" "+anagrams.getValue(sortString(key))+" ");
		}
		
		// open the output file to list all of the anagrams in the dictionary
		
		PrintWriter outputFile = new PrintWriter("src\\Task2_Anagrams\\anagrams.txt");
		
		outputFile.println("********* Showing all keys and anagrams - total = " + anagrams.size());
		
		// insert your code here to write all keys and values to the anagrams.txt file.
		// only use the iterators to do this.
		// the output should match anagramsAssignmentOutput.txt exactly
		
		Iterator<String> keyList = anagrams.getKeyIterator();
		
		while(keyList.hasNext()){
			String key = keyList.next();
			outputFile.println(key + ": " + anagrams.getValue(key));
		}
		outputFile.close();

	}

	/**
	 * Sorts a word by its characters and places them in the output string
	 * @param word
	 * @return string of sorted letters based on the input
	 */
	private static String sortString(String word) {
		char[] wordCharacters = word.toCharArray();
		Arrays.sort(wordCharacters);
		return new String(wordCharacters);
	}

	/**
	 * Create a list of anagrams from a dictionary file and place into a Dictionary. An anagram has key which is a set
	 * of sorted characters, and a value consisting of an array of strings that are legal words in the dictionary that match
	 * the characters in the key.
	 * 
	 * anagramsMap for this assignment must use a hash table.
	 * @param fileName for dictionary words. Each word in the file should be on a separate line.
	 * @param anagramsMap resulting anagrams table
	 * @throws IOException
	 */
	private static void createAnagrams(String fileName, DictionaryInterface<String, ArrayList<String>> anagramsMap)
			throws IOException {
		//call file
		Scanner textReader = new Scanner(new File(fileName));
		ArrayList wordList;
		
		while(textReader.hasNextLine()) {

			wordList = new ArrayList<String>(); // using java library, will add list of words

			String value = textReader.nextLine(); //get value
			String key = sortString(value); 
			
			//check whether current key exists or not
			if(anagramsMap.contains(key)) {
				//key exists
				wordList = anagramsMap.getValue(key);
			} 
			
			//add value to wordList
			wordList.add(value);
			anagramsMap.add(key, wordList);
		}
	}

}
